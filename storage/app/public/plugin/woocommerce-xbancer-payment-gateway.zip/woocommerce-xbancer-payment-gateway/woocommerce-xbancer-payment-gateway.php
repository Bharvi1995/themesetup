<?php
/* @wordpress-plugin
 * Plugin Name:       WooCommerce Xbancer Direct Payment Gateway
 * Plugin URI:        https://xbancer.com/
 * Description:       Xbancer Direct Card Payment is help to do payment using third party debit card/credit card payment getway.
 * Version:           1.1.0
 * WC requires at least: 3.0
 * WC tested up to: 5.3
 * Author:            Xbancer
 * Author URI:        https://xbancer.com/contact-us/
 * Text Domain:       woocommerce-xbancer-payment-gateway
 * Domain Path: /languages
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

$active_plugins = apply_filters('active_plugins', get_option('active_plugins'));
if(xbancer_custom_payment_is_woocommerce_active()){
	add_filter('woocommerce_payment_gateways', 'add_xbancer_payment_gateway');
	function add_xbancer_payment_gateway( $gateways ){
		$gateways[] = 'WC_Xbancer_Payment_Gateway';
		return $gateways;
	}
	
	add_action('plugins_loaded', 'init_xbancer_payment_gateway');
	function init_xbancer_payment_gateway(){
		require 'class-woocommerce-xbancer-payment-gateway.php';
	}

	add_action( 'plugins_loaded', 'xbancer_payment_load_plugin_textdomain' );
	function xbancer_payment_load_plugin_textdomain() {
	  load_plugin_textdomain( 'woocommerce-xbancer-payment-gateway', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
	}

}


/**
 * @return bool
 */
function xbancer_custom_payment_is_woocommerce_active()
{
	$active_plugins = (array) get_option('active_plugins', array());

	if (is_multisite()) {
		$active_plugins = array_merge($active_plugins, get_site_option('active_sitewide_plugins', array()));
	}

	return in_array('woocommerce/woocommerce.php', $active_plugins) || array_key_exists('woocommerce/woocommerce.php', $active_plugins);
}

add_action('wp_enqueue_scripts','custom_xbancer_java_cript');
function custom_xbancer_java_cript() {
	wp_enqueue_script('nosir-cleave','https://nosir.github.io/cleave.js/dist/cleave.min.js','','',true);
}

add_action(
	'woocommerce_endpoint_order-received_title',
	function( $title ) {
		global $wp;
		$order_id  = isset( $wp->query_vars['order-received'] ) ? absint( $wp->query_vars['order-received'] ) : 0;
		$order = wc_get_order( $order_id );
		if ( $order && $order->has_status( 'failed' ) ) {
			return 'Payment Failed';
		}

		return $title;
	}
);