<?php
class WC_Xbancer_Payment_Gateway extends WC_Payment_Gateway{

    private $order_status;

	public function __construct(){
		$this->id = 'xbancer_payment';
		$this->method_title = __('Xbancer Payment','woocommerce-xbancer-payment-gateway');
		$this->method_description = __('Xbancer Payment getway provide direct payment','woocommerce-xbancer-payment-gateway');
		$this->title = __('Xbancer Payment','woocommerce-xbancer-payment-gateway');
		$this->has_fields = true;
		$this->init_form_fields();
		$this->init_settings();
		$this->enabled = $this->get_option('enabled');
		$this->title = $this->get_option('title');
		$this->description = $this->get_option('description');
		$this->hide_text_box = $this->get_option('hide_text_box');
		$this->text_box_required = $this->get_option('text_box_required');
		$this->order_status = $this->get_option('order_status');
	
		add_action('woocommerce_update_options_payment_gateways_'.$this->id, array($this, 'process_admin_options'));
	}

	public function init_form_fields(){
		$this->form_fields = array(
			'enabled' => array(
			'title' 		=> __( 'Enable/Disable', 'woocommerce-xbancer-payment-gateway' ),
			'type' 			=> 'checkbox',
			'label' 		=> __( 'Enable Xbancer Payment', 'woocommerce-xbancer-payment-gateway' ),
			'default' 		=> 'no'
			),

			'title' => array(
				'title' 		=> __( 'Method Title', 'woocommerce-xbancer-payment-gateway' ),
				'type' 			=> 'text',
				'description' 	=> __( 'This controls the title', 'woocommerce-xbancer-payment-gateway' ),
				'default'		=> __( 'Custom Payment', 'woocommerce-xbancer-payment-gateway' ),
				'desc_tip'		=> true,
			),
			'description' => array(
				'title' => __( 'Customer Message', 'woocommerce-xbancer-payment-gateway' ),
				'type' => 'textarea',
				'css' => 'width:500px;',
				'default' => 'None of the other payment options are suitable for you? please drop us a note about your favourable payment option and we will contact you as soon as possible.',
				'description' 	=> __( 'The message which you want it to appear to the customer in the checkout page.', 'woocommerce-xbancer-payment-gateway' ),
			),
			'testmode' => array(
				'title' 		=> __( 'TestMode', 'woocommerce-xbancer-payment-gateway' ),
				'type' 			=> 'checkbox',
				'label' 		=> __( 'TestMode Enable for test Xbancer Payment', 'woocommerce-xbancer-payment-gateway' ),
				'default' 		=> 'yes'
			),
			'api_key' => array(
				'title' 		=> __( 'API Key', 'woocommerce-xbancer-payment-gateway' ),
				'type' 			=> 'text',
				'description' 	=> __( 'Api key', 'woocommerce-xbancer-payment-gateway' ),
				'default'		=> __( 'Api Key', 'woocommerce-xbancer-payment-gateway' ),
				'desc_tip'		=> true,
			),
			'order_status' => array(
				'title' => __( 'Order Status After The Checkout', 'woocommerce-xbancer-payment-gateway' ),
				'type' => 'select',
				'options' => wc_get_order_statuses(),
				'default' => 'wc-on-hold',
				'description' 	=> __( 'The default order status if this gateway used in payment.', 'woocommerce-xbancer-payment-gateway' ),
			),
		);
	}
	

	public function validate_fields() {
	    if($this->text_box_required === 'no'){
	        return true;
        }

		return true;
	}

	public function process_payment( $order_id ) {
		global $woocommerce;
		$order = new WC_Order( $order_id );
		$user_id = get_post_meta( $order_id, '_customer_user', true );

		// Get an instance of the WC_Customer Object from the user ID
		$customer = new WC_Customer( $user_id );
		$amount =  (float) $order->get_total();;
		$user_email   = $customer->get_billing_email();		// Get account email
		$currency = get_woocommerce_currency();
		$mobile = $customer->get_billing_phone();
		$billing_first_name = $customer->get_billing_first_name();
		$billing_last_name  = $customer->get_billing_last_name();
		$billing_company    = $customer->get_billing_company();
		$billing_address_1  = $customer->get_billing_address_1();
		$billing_address_2  = $customer->get_billing_address_2();
		$billing_city       = $customer->get_billing_city();
		$billing_state      = $customer->get_billing_state();
		$billing_postcode   = $customer->get_billing_postcode();
		$billing_country    = $customer->get_billing_country();
		
		$ip = $_SERVER['REMOTE_ADDR'];
		$apikey = $this->woocommerce_xbancer_payment_api_key;
		$apikey = $this->settings['api_key'];
		$mode = $this->settings['testmode'];
		if($mode == 'yes'){
			$url = 'https://gateway.xbancer.com/api/test/transaction';
		}else if($mode == 'no'){
			$url = 'https://gateway.xbancer.com/api/transaction';
		}

		if( isset($_POST['billing_state']) && !empty($_POST['billing_state']) ){
			$state = $_POST['billing_state'];
		}else{
			$state = "NA";
		}

		if( isset($_POST['billing_phone']) && !empty($_POST['billing_phone']) ){
			$phone_no = $_POST['billing_phone'];
		}else{
			$phone_no = "NA";
		}

		$cardNo = str_replace(" ", "", $_POST['card']['cardno']);
		$exiperydate = explode("/", $_POST['card']['exiperydate']);
		$exiperMonth = $exiperydate[0];
		$exiperYear = "20".$exiperydate[1];
		$args = array(
			'first_name' => $_POST['billing_first_name'],
			'last_name' => $_POST['billing_last_name'],
			'address' => $_POST['billing_address_1'].''.$_POST['billing_address_2'],
			'country' => $_POST['billing_country'],
			'state' => $state,
			'city' => $_POST['billing_city'],
			'zip' => $_POST['billing_postcode'],
			'ip_address' => $ip,
			'email' => $_POST['billing_email'],
			'phone_no' => $phone_no,
			'amount' => sprintf('%0.2f', $amount),
			'currency' => $currency,
			'card_no' => $cardNo,
			'ccExpiryMonth' => $exiperMonth,
			'ccExpiryYear' => $exiperYear,
			'cvvNumber' => $_POST['card']['cvv'],
			'customer_order_id' => $order_id,
			'response_url' => site_url('xbancer-callback'),
			'webhook_url' => admin_url('admin-ajax.php')."?action=xbancer_update_pending_tx&ostatus=".$this->order_status,
		);

		if( $order->status == "failed" ){
			$args['first_name'] = $order->get_billing_first_name();
			$args['last_name'] = $order->get_billing_last_name();
			$args['address'] = $order->get_billing_address_1();
			$args['country'] = $order->get_billing_country();
			$args['state'] = $order->get_billing_state();
			$args['city'] = $order->get_billing_city();
			$args['zip'] = $order->get_billing_postcode();
			$args['email'] = $order->get_billing_email();
			$args['phone_no'] = $order->get_billing_phone();
		}

		$curl = curl_init();
		$postData = json_encode($args);
		curl_setopt_array($curl, array(
			  CURLOPT_URL => $url,
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => '',
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_SSL_VERIFYHOST => false,
			  CURLOPT_SSL_VERIFYPEER => false,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => 'POST',
			  CURLOPT_POSTFIELDS =>$postData,
			  CURLOPT_HTTPHEADER => array(
					'Content-Type: application/json',
					'Authorization: Bearer '.$apikey
			  ),
		));

		$response = curl_exec($curl);

		curl_close($curl);
		$result = json_decode($response, true);		
		if(isset($result['responseCode']) && $result['responseCode'] == '1'){
		// Mark as on-hold (we're awaiting the cheque)
		$order->update_status($this->order_status, __( 'Awaiting payment', 'woocommerce-xbancer-payment-gateway' ));
		// Reduce stock levels
		wc_reduce_stock_levels( $order_id );
		add_action('woocommerce_before_thankyou', 'custome_message_payment_xbancer_success');
		
		$order->add_order_note(esc_html('payment_order_id : '.$result['data']['transaction']['order_id']),1);
		
		// Remove cart
		$woocommerce->cart->empty_cart();
			// Return thankyou redirect
			return array(
				'result' => 'success',
				'order_no' => $result['data']['transaction']['order_id'],
				'redirect' => $this->get_return_url( $order )
			);
		}else if(isset($result['responseCode']) && $result['responseCode'] == '7'){
			wc_reduce_stock_levels( $order_id );
			$order->update_status("processing", __( 'Awaiting payment', 'woocommerce-xbancer-payment-gateway' ));
			$order->add_order_note(esc_html('Order goes to the 3ds redirect : '.$result['3dsUrl']),1);
		
			// Remove cart
			$woocommerce->cart->empty_cart();
			return array(
				'result' => 'success',
				'redirect' => $result['3dsUrl']
			);
			
		}else{
			$messageError = "Error : ";
			if( isset($result['errors']) && !empty($result['errors']) ){
					foreach( $result['errors'] as $error ){
							$messageError .= $error[0].",";
					}
				$messageError = rtrim($messageError, ",");
				wc_add_notice( __($messageError,'woocommerce-xbancer-payment-gateway'), 'error');
			}else{
				wc_add_notice( __($result['responseMessage'],'woocommerce-xbancer-payment-gateway'), 'error');
			}
			return false;
		}
	}

	public function payment_fields(){
	    ?>
		<fieldset>
			<div class='form-row'>
				<div class='col-xs-12 form-group card required'>
					<label class='control-label'>Card Number</label>
					<input name="card[cardno]" class='form-control credit-card-fields card-number' placeholder="0000 0000 0000 0000" type='tel'>
					<ul class="cards-icons clearfix">
						<li class="amex-card">
							<svg xmlns="http://www.w3.org/2000/svg" height="16" width="18" viewBox="0 0 576 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2023 Fonticons, Inc.--><path d="M0 432c0 26.5 21.5 48 48 48H528c26.5 0 48-21.5 48-48v-1.1H514.3l-31.9-35.1-31.9 35.1H246.8V267.1H181L262.7 82.4h78.6l28.1 63.2V82.4h97.2L483.5 130l17-47.6H576V80c0-26.5-21.5-48-48-48H48C21.5 32 0 53.5 0 80V432zm440.4-21.7L482.6 364l42 46.3H576l-68-72.1 68-72.1H525.4l-42 46.7-41.5-46.7H390.5L458 338.6l-67.4 71.6V377.1h-83V354.9h80.9V322.6H307.6V300.2h83V267.1h-122V410.3H440.4zm96.3-72L576 380.2V296.9l-39.3 41.4zm-36.3-92l36.9-100.6V246.3H576V103H515.8l-32.2 89.3L451.7 103H390.5V246.1L327.3 103H276.1L213.7 246.3h43l11.9-28.7h65.9l12 28.7h82.7V146L466 246.3h34.4zM282 185.4l19.5-46.9 19.4 46.9H282z"/></svg>
						</li>
						<li class="visa-card">
							<svg xmlns="http://www.w3.org/2000/svg" height="16" width="18" viewBox="0 0 576 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2023 Fonticons, Inc.--><path d="M470.1 231.3s7.6 37.2 9.3 45H446c3.3-8.9 16-43.5 16-43.5-.2 .3 3.3-9.1 5.3-14.9l2.8 13.4zM576 80v352c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V80c0-26.5 21.5-48 48-48h480c26.5 0 48 21.5 48 48zM152.5 331.2L215.7 176h-42.5l-39.3 106-4.3-21.5-14-71.4c-2.3-9.9-9.4-12.7-18.2-13.1H32.7l-.7 3.1c15.8 4 29.9 9.8 42.2 17.1l35.8 135h42.5zm94.4 .2L272.1 176h-40.2l-25.1 155.4h40.1zm139.9-50.8c.2-17.7-10.6-31.2-33.7-42.3-14.1-7.1-22.7-11.9-22.7-19.2 .2-6.6 7.3-13.4 23.1-13.4 13.1-.3 22.7 2.8 29.9 5.9l3.6 1.7 5.5-33.6c-7.9-3.1-20.5-6.6-36-6.6-39.7 0-67.6 21.2-67.8 51.4-.3 22.3 20 34.7 35.2 42.2 15.5 7.6 20.8 12.6 20.8 19.3-.2 10.4-12.6 15.2-24.1 15.2-16 0-24.6-2.5-37.7-8.3l-5.3-2.5-5.6 34.9c9.4 4.3 26.8 8.1 44.8 8.3 42.2 .1 69.7-20.8 70-53zM528 331.4L495.6 176h-31.1c-9.6 0-16.9 2.8-21 12.9l-59.7 142.5H426s6.9-19.2 8.4-23.3H486c1.2 5.5 4.8 23.3 4.8 23.3H528z"/></svg>
						</li>
						<li class="dinner-card">
							<svg xmlns="http://www.w3.org/2000/svg" height="16" width="18" viewBox="0 0 576 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2023 Fonticons, Inc.--><path d="M239.7 79.9c-96.9 0-175.8 78.6-175.8 175.8 0 96.9 78.9 175.8 175.8 175.8 97.2 0 175.8-78.9 175.8-175.8 0-97.2-78.6-175.8-175.8-175.8zm-39.9 279.6c-41.7-15.9-71.4-56.4-71.4-103.8s29.7-87.9 71.4-104.1v207.9zm79.8 .3V151.6c41.7 16.2 71.4 56.7 71.4 104.1s-29.7 87.9-71.4 104.1zM528 32H48C21.5 32 0 53.5 0 80v352c0 26.5 21.5 48 48 48h480c26.5 0 48-21.5 48-48V80c0-26.5-21.5-48-48-48zM329.7 448h-90.3c-106.2 0-193.8-85.5-193.8-190.2C45.6 143.2 133.2 64 239.4 64h90.3c105 0 200.7 79.2 200.7 193.8 0 104.7-95.7 190.2-200.7 190.2z"/></svg>
						</li>
						<li class="master-card">
							<svg xmlns="http://www.w3.org/2000/svg" height="16" width="18" viewBox="0 0 576 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2023 Fonticons, Inc.--><path d="M482.9 410.3c0 6.8-4.6 11.7-11.2 11.7-6.8 0-11.2-5.2-11.2-11.7 0-6.5 4.4-11.7 11.2-11.7 6.6 0 11.2 5.2 11.2 11.7zm-310.8-11.7c-7.1 0-11.2 5.2-11.2 11.7 0 6.5 4.1 11.7 11.2 11.7 6.5 0 10.9-4.9 10.9-11.7-.1-6.5-4.4-11.7-10.9-11.7zm117.5-.3c-5.4 0-8.7 3.5-9.5 8.7h19.1c-.9-5.7-4.4-8.7-9.6-8.7zm107.8 .3c-6.8 0-10.9 5.2-10.9 11.7 0 6.5 4.1 11.7 10.9 11.7 6.8 0 11.2-4.9 11.2-11.7 0-6.5-4.4-11.7-11.2-11.7zm105.9 26.1c0 .3 .3 .5 .3 1.1 0 .3-.3 .5-.3 1.1-.3 .3-.3 .5-.5 .8-.3 .3-.5 .5-1.1 .5-.3 .3-.5 .3-1.1 .3-.3 0-.5 0-1.1-.3-.3 0-.5-.3-.8-.5-.3-.3-.5-.5-.5-.8-.3-.5-.3-.8-.3-1.1 0-.5 0-.8 .3-1.1 0-.5 .3-.8 .5-1.1 .3-.3 .5-.3 .8-.5 .5-.3 .8-.3 1.1-.3 .5 0 .8 0 1.1 .3 .5 .3 .8 .3 1.1 .5s.2 .6 .5 1.1zm-2.2 1.4c.5 0 .5-.3 .8-.3 .3-.3 .3-.5 .3-.8 0-.3 0-.5-.3-.8-.3 0-.5-.3-1.1-.3h-1.6v3.5h.8V426h.3l1.1 1.4h.8l-1.1-1.3zM576 81v352c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V81c0-26.5 21.5-48 48-48h480c26.5 0 48 21.5 48 48zM64 220.6c0 76.5 62.1 138.5 138.5 138.5 27.2 0 53.9-8.2 76.5-23.1-72.9-59.3-72.4-171.2 0-230.5-22.6-15-49.3-23.1-76.5-23.1-76.4-.1-138.5 62-138.5 138.2zm224 108.8c70.5-55 70.2-162.2 0-217.5-70.2 55.3-70.5 162.6 0 217.5zm-142.3 76.3c0-8.7-5.7-14.4-14.7-14.7-4.6 0-9.5 1.4-12.8 6.5-2.4-4.1-6.5-6.5-12.2-6.5-3.8 0-7.6 1.4-10.6 5.4V392h-8.2v36.7h8.2c0-18.9-2.5-30.2 9-30.2 10.2 0 8.2 10.2 8.2 30.2h7.9c0-18.3-2.5-30.2 9-30.2 10.2 0 8.2 10 8.2 30.2h8.2v-23zm44.9-13.7h-7.9v4.4c-2.7-3.3-6.5-5.4-11.7-5.4-10.3 0-18.2 8.2-18.2 19.3 0 11.2 7.9 19.3 18.2 19.3 5.2 0 9-1.9 11.7-5.4v4.6h7.9V392zm40.5 25.6c0-15-22.9-8.2-22.9-15.2 0-5.7 11.9-4.8 18.5-1.1l3.3-6.5c-9.4-6.1-30.2-6-30.2 8.2 0 14.3 22.9 8.3 22.9 15 0 6.3-13.5 5.8-20.7 .8l-3.5 6.3c11.2 7.6 32.6 6 32.6-7.5zm35.4 9.3l-2.2-6.8c-3.8 2.1-12.2 4.4-12.2-4.1v-16.6h13.1V392h-13.1v-11.2h-8.2V392h-7.6v7.3h7.6V416c0 17.6 17.3 14.4 22.6 10.9zm13.3-13.4h27.5c0-16.2-7.4-22.6-17.4-22.6-10.6 0-18.2 7.9-18.2 19.3 0 20.5 22.6 23.9 33.8 14.2l-3.8-6c-7.8 6.4-19.6 5.8-21.9-4.9zm59.1-21.5c-4.6-2-11.6-1.8-15.2 4.4V392h-8.2v36.7h8.2V408c0-11.6 9.5-10.1 12.8-8.4l2.4-7.6zm10.6 18.3c0-11.4 11.6-15.1 20.7-8.4l3.8-6.5c-11.6-9.1-32.7-4.1-32.7 15 0 19.8 22.4 23.8 32.7 15l-3.8-6.5c-9.2 6.5-20.7 2.6-20.7-8.6zm66.7-18.3H408v4.4c-8.3-11-29.9-4.8-29.9 13.9 0 19.2 22.4 24.7 29.9 13.9v4.6h8.2V392zm33.7 0c-2.4-1.2-11-2.9-15.2 4.4V392h-7.9v36.7h7.9V408c0-11 9-10.3 12.8-8.4l2.4-7.6zm40.3-14.9h-7.9v19.3c-8.2-10.9-29.9-5.1-29.9 13.9 0 19.4 22.5 24.6 29.9 13.9v4.6h7.9v-51.7zm7.6-75.1v4.6h.8V302h1.9v-.8h-4.6v.8h1.9zm6.6 123.8c0-.5 0-1.1-.3-1.6-.3-.3-.5-.8-.8-1.1-.3-.3-.8-.5-1.1-.8-.5 0-1.1-.3-1.6-.3-.3 0-.8 .3-1.4 .3-.5 .3-.8 .5-1.1 .8-.5 .3-.8 .8-.8 1.1-.3 .5-.3 1.1-.3 1.6 0 .3 0 .8 .3 1.4 0 .3 .3 .8 .8 1.1 .3 .3 .5 .5 1.1 .8 .5 .3 1.1 .3 1.4 .3 .5 0 1.1 0 1.6-.3 .3-.3 .8-.5 1.1-.8 .3-.3 .5-.8 .8-1.1 .3-.6 .3-1.1 .3-1.4zm3.2-124.7h-1.4l-1.6 3.5-1.6-3.5h-1.4v5.4h.8v-4.1l1.6 3.5h1.1l1.4-3.5v4.1h1.1v-5.4zm4.4-80.5c0-76.2-62.1-138.3-138.5-138.3-27.2 0-53.9 8.2-76.5 23.1 72.1 59.3 73.2 171.5 0 230.5 22.6 15 49.5 23.1 76.5 23.1 76.4 .1 138.5-61.9 138.5-138.4z"/></svg>
						</li>
						<li class="jcb-card">
							<svg xmlns="http://www.w3.org/2000/svg" height="16" width="18" viewBox="0 0 576 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2023 Fonticons, Inc.--><path d="M431.5 244.3V212c41.2 0 38.5 .2 38.5 .2 7.3 1.3 13.3 7.3 13.3 16 0 8.8-6 14.5-13.3 15.8-1.2 .4-3.3 .3-38.5 .3zm42.8 20.2c-2.8-.7-3.3-.5-42.8-.5v35c39.6 0 40 .2 42.8-.5 7.5-1.5 13.5-8 13.5-17 0-8.7-6-15.5-13.5-17zM576 80v352c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V80c0-26.5 21.5-48 48-48h480c26.5 0 48 21.5 48 48zM182 192.3h-57c0 67.1 10.7 109.7-35.8 109.7-19.5 0-38.8-5.7-57.2-14.8v28c30 8.3 68 8.3 68 8.3 97.9 0 82-47.7 82-131.2zm178.5 4.5c-63.4-16-165-14.9-165 59.3 0 77.1 108.2 73.6 165 59.2V287C312.9 311.7 253 309 253 256s59.8-55.6 107.5-31.2v-28zM544 286.5c0-18.5-16.5-30.5-38-32v-.8c19.5-2.7 30.3-15.5 30.3-30.2 0-19-15.7-30-37-31 0 0 6.3-.3-120.3-.3v127.5h122.7c24.3 .1 42.3-12.9 42.3-33.2z"/></svg>
						</li>
						<li class="discover-card">
							<svg xmlns="http://www.w3.org/2000/svg" height="16" width="18" viewBox="0 0 576 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2023 Fonticons, Inc.--><path d="M520.4 196.1c0-7.9-5.5-12.1-15.6-12.1h-4.9v24.9h4.7c10.3 0 15.8-4.4 15.8-12.8zM528 32H48C21.5 32 0 53.5 0 80v352c0 26.5 21.5 48 48 48h480c26.5 0 48-21.5 48-48V80c0-26.5-21.5-48-48-48zm-44.1 138.9c22.6 0 52.9-4.1 52.9 24.4 0 12.6-6.6 20.7-18.7 23.2l25.8 34.4h-19.6l-22.2-32.8h-2.2v32.8h-16zm-55.9 .1h45.3v14H444v18.2h28.3V217H444v22.2h29.3V253H428zm-68.7 0l21.9 55.2 22.2-55.2h17.5l-35.5 84.2h-8.6l-35-84.2zm-55.9-3c24.7 0 44.6 20 44.6 44.6 0 24.7-20 44.6-44.6 44.6-24.7 0-44.6-20-44.6-44.6 0-24.7 20-44.6 44.6-44.6zm-49.3 6.1v19c-20.1-20.1-46.8-4.7-46.8 19 0 25 27.5 38.5 46.8 19.2v19c-29.7 14.3-63.3-5.7-63.3-38.2 0-31.2 33.1-53 63.3-38zm-97.2 66.3c11.4 0 22.4-15.3-3.3-24.4-15-5.5-20.2-11.4-20.2-22.7 0-23.2 30.6-31.4 49.7-14.3l-8.4 10.8c-10.4-11.6-24.9-6.2-24.9 2.5 0 4.4 2.7 6.9 12.3 10.3 18.2 6.6 23.6 12.5 23.6 25.6 0 29.5-38.8 37.4-56.6 11.3l10.3-9.9c3.7 7.1 9.9 10.8 17.5 10.8zM55.4 253H32v-82h23.4c26.1 0 44.1 17 44.1 41.1 0 18.5-13.2 40.9-44.1 40.9zm67.5 0h-16v-82h16zM544 433c0 8.2-6.8 15-15 15H128c189.6-35.6 382.7-139.2 416-160zM74.1 191.6c-5.2-4.9-11.6-6.6-21.9-6.6H48v54.2h4.2c10.3 0 17-2 21.9-6.4 5.7-5.2 8.9-12.8 8.9-20.7s-3.2-15.5-8.9-20.5z"/></svg>
						</li>
					</ul>
				</div>
            </div>
            <div class='form-row'>
				<div class='col-xs-6 col-md-4 form-group expiration required'>
					<label class='control-label'>Expiration Date</label>
					<input class='form-control card-expiry-date' name="card[exiperydate]" placeholder='MM/YY' type='text'>
				</div>
				<div class='col-xs-6 col-md-4 form-group cvc required'>
					<label class='control-label'>CVC</label>
					<input autocomplete='off' class='form-control card-cvc' name="card[cvv]" placeholder='ex. 311' type='password'>
				</div>
            </div>
		</fieldset>
		<style>
			.cards-icons{
				margin-top : 0px !important;
				margin-bottom : 30px !important;
			}
			.cards-icons li{
				display : inline-block;
			}
			.cards-icons li svg{
				fill : #CBCBCB;
				width: 30px;
				height: 30px;
			}
			.cards-icons li.active svg{
				fill : #000000;
			}
		</style>
		<script>
			(function($){

				$(document).ready(function(){
					var cleave = new Cleave('.credit-card-fields', {
						creditCard: true,
						onCreditCardTypeChanged: function (type) {
							console.log( type );
							$("ul.cards-icons li").removeClass("active");
							if( type == "visa" ){
								$("ul.cards-icons li.visa-card").addClass("active");
							}
							if( type == "amex" ){
								$("ul.cards-icons li.amex-card").addClass("active");
							}
							if( type == "diners" ){
								$("ul.cards-icons li.dinner-card").addClass("active");
							}
							if( type == "mastercard" ){
								$("ul.cards-icons li.master-card").addClass("active");
							}
							if( type == "jcb" ){
								$("ul.cards-icons li.jcb-card").addClass("active");
							}
							if( type == "discover" ){
								$("ul.cards-icons li.discover-card").addClass("active");
							}
						}
					});   
					var cleave = new Cleave('.card-expiry-date', {
						date: true,
						datePattern: ['m', 'y']
					});

				});

			})(jQuery);
		</script>
		<?php
	}
}

function xbancerupdatePendingTranscations() {

			$rawdata = file_get_contents("php://input");
			$orderDetails = json_decode($rawdata, true);

			$orderId = $orderDetails['data']['transaction']['customer_order_id'];
			$ostatus = $_REQUEST['ostatus'];
			$status = $orderDetails['responseCode'];
			$message = isset($orderDetails['responseMessage']) ? $orderDetails['responseMessage'] : '';
			
			global $woocommerce;

			// we need it to get any order detailes
			$order = wc_get_order( $orderId );
			$order->add_order_note(esc_html('Order webhook response : '.json_encode($orderDetails)),1);
			$order->add_order_note( $message, true );

			if( $status == "1" ){

				// we need it to get any order detailes

				$order->payment_complete();
				$order->reduce_order_stock();
				$order->add_order_note( $message, true );
			  $order->update_status( $ostatus, $message );
				$woocommerce->cart->empty_cart();
        wc_add_notice($message,'Success');
				wc_add_notice( __( $message, 'woocommerce' ), 'success' );

			}elseif( $status == "2" ){

				$order->payment_complete();
				$order->reduce_order_stock();
				$order->add_order_note( $message, true );
			  $order->update_status( 'wc-failed', $message );
				$woocommerce->cart->empty_cart();
        wc_add_notice($message,'Error');
				wc_add_notice( __( $message, 'woocommerce' ), 'error' );

			}else{

				$order->add_order_note( $message, true );
        $order->update_status( 'wc-failed', $message );
        $woocommerce->cart->empty_cart();
        wc_add_notice($message,'Error');
				wc_add_notice( __( $message, 'woocommerce' ), 'error' );

			}


    wp_die();
}

add_action( 'wp_ajax_nopriv_xbancer_update_pending_tx', 'xbancerupdatePendingTranscations' );
add_action( 'wp_ajax_xbancer_update_pending_tx', 'xbancerupdatePendingTranscations' );

add_filter('query_vars', 'xbancer_query_vars');
add_action('init', 'xbancer_payment_callback_urls');

function xbancer_query_vars($vars){
  $vars[] = 'responseCode';
  $vars[] = 'responseMessage';
  $vars[] = 'order_id';
  $vars[] = 'customer_order_id';
  return $vars;
}

function xbancer_payment_callback_urls() {

  add_rewrite_rule(
    '^xbancer-callback/(\w)?',
    'index.php?customer_order_id=$matches[1]',
    'top'
  );

}
add_action('parse_request', 'xbancer_total_callback');
function xbancer_total_callback( $wp ){
	$xbancerTotalCallback = new XbancerTotalCallback();
	$xbancerTotalCallback->xbancerCallback($wp);
}


class XbancerTotalCallback extends WC_Payment_Gateway {
    
		private $order_status;

		public function __construct(){
	
			$this->id = 'xbancer_payment';
			$this->method_title = __('Xbancer Payment','woocommerce-xbancer-payment-gateway');
			$this->method_description = __('Xbancer Payment getway provide direct payment','woocommerce-xbancer-payment-gateway');
			$this->title = __('Xbancer Payment','woocommerce-xbancer-payment-gateway');
			$this->init_settings();
			$this->order_status = $this->get_option('order_status');

		}

    public function xbancerCallback( $wp ) {
    	$valid_actions = array('customer_order_id');

			if( isset($wp->query_vars['customer_order_id']) && !empty($wp->query_vars['customer_order_id']) ) {
			
			$orderId = $wp->query_vars['customer_order_id'];
			$status = $wp->query_vars['responseCode'];
			$message = isset($wp->query_vars['responseMessage']) ? $wp->query_vars['responseMessage'] : '';
			if( empty($message) ){
				$message = isset( $wp->query_vars['responseMessage'] ) ? $wp->query_vars['responseMessage'] : "";
			}
			
			if( $status == "1" ){
				
				global $woocommerce;

				// we need it to get any order detailes
				$order = wc_get_order( $orderId );

				$order->payment_complete();
				$order->reduce_order_stock();
				$order->add_order_note( $message, true );
                $order->update_status( $this->order_status, $message );
				$woocommerce->cart->empty_cart();
                wc_add_notice($message,'Success');
				wc_add_notice( __( $message, 'woocommerce' ), 'success' );
				$order_url = $this->get_return_url( $order );
				wp_redirect($order_url);
				exit;
				
			}elseif( $status == "2" ){

				global $woocommerce;

				// we need it to get any order detailes
				$order = wc_get_order( $orderId );

				$order->payment_complete();
				$order->reduce_order_stock();
				$order->add_order_note( $message, true );
			  $order->update_status( 'wc-failed', $message );
				$woocommerce->cart->empty_cart();
        wc_add_notice($message,'Error');
				wc_add_notice( __( $message, 'woocommerce' ), 'error' );
				$order_url = $this->get_return_url( $order );
				wp_redirect($order_url);
				exit;

			}else{
				global $woocommerce;
				$order = wc_get_order( $orderId );
				$order->add_order_note( $message, true );
                $order->update_status( 'wc-failed', $message );
                $woocommerce->cart->empty_cart();
                wc_add_notice($message,'Error');
				wc_add_notice( __( $message, 'woocommerce' ), 'error' );
				$order_url = $this->get_return_url( $order );
				wp_redirect($order_url);
				exit;
				
			}

		}
    }
}